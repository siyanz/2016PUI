var project = {
	"name": "placehold", 
	"id": "0-placehold", 
	"thumbnail": "http://placehold.it/500x300", 
	"img": "http://placehold.it/750x500",
	"description": "This project was done in collaboration with John Doe and Jane Doe. The project focuses on lorem ipsum"
	}


// This creates the grid at the bottom of the page
$( document ).ready(function (){
	// Retrieve the template data from the HTML (jQuery is used here).
	
	// Compile the template data into a function

	// Create HTML code
	
	// Insert the HTML code into the page
	
});

